﻿# 大作业实战Pipeline

#### 这里统计了本期学员的最后的大作业实战Pipeline

- https://github.com/exuding/NLP/blob/master/bert_classification.ipynb
- https://github.com/exuding/NLP/blob/master/fastText_classification.ipynb
- https://chenk.tech/posts/aefe1ee4.html
- https://github.com/hu-minghao/my_program/blob/master/NLP-task5%2Bbig%2Bhomework.ipynb




---
#### 以下整理了各个Task的优秀打卡链接，供学习者学习参考！

##### Task1

- [ https://blog.csdn.net/Rock_y/article/details/106940001 ](https://blog.csdn.net/Rock_y/article/details/106940001)
-  https://blog.csdn.net/weixin_42691585/article/details/106928998 
-  [https://](https://www.jianshu.com/p/8594cf51bf89)[www](https://www.jianshu.com/p/8594cf51bf89)[.](https://www.jianshu.com/p/8594cf51bf89)[jia](https://www.jianshu.com/p/8594cf51bf89)[n](https://www.jianshu.com/p/8594cf51bf89)[shu](https://www.jianshu.com/p/8594cf51bf89)[.](https://www.jianshu.com/p/8594cf51bf89)[com](https://www.jianshu.com/p/8594cf51bf89)[/](https://www.jianshu.com/p/8594cf51bf89)[p/](https://www.jianshu.com/p/8594cf51bf89)[85](https://www.jianshu.com/p/8594cf51bf89)[94](https://www.jianshu.com/p/8594cf51bf89)[c](https://www.jianshu.com/p/8594cf51bf89)[f5](https://www.jianshu.com/p/8594cf51bf89)[1](https://www.jianshu.com/p/8594cf51bf89)[bf](https://www.jianshu.com/p/8594cf51bf89)[89](https://www.jianshu.com/p/8594cf51bf89) 
-  https://billmazengou.github.io/2020/06/23/NLP1-Word-to-Vectors/ 

##### Task2

-  https://blog.csdn.net/Rock_y/article/details/106986586 
-  https://blog.csdn.net/weixin_42691585/article/details/106988635 
-  [https://blog.csdn.net/w](https://blog.csdn.net/wuzhongqiang/article/details/106979179)[uzhongq](https://blog.csdn.net/wuzhongqiang/article/details/106979179)[i](https://blog.csdn.net/wuzhongqiang/article/details/106979179)[a](https://blog.csdn.net/wuzhongqiang/article/details/106979179)[n](https://blog.csdn.net/wuzhongqiang/article/details/106979179)[g](https://blog.csdn.net/wuzhongqiang/article/details/106979179)[/article/details/1069](https://blog.csdn.net/wuzhongqiang/article/details/106979179)[79179](https://blog.csdn.net/wuzhongqiang/article/details/106979179) 

##### Task3

- https://blog.csdn.net/weixin_42691585/article/details/107009195

##### Task4

-  https://blog.csdn.net/weixin_42691585/article/details/107071763 
-  https://blog.csdn.net/weixin_45684408/article/details/107093246 